#!/usr/bin/env python3
"""Only audited complete formal groups enter plots. Local smoke is excluded."""
import argparse,csv,json,math,pathlib,statistics
p=argparse.ArgumentParser();p.add_argument('--input',required=True);p.add_argument('--out',required=True);args=p.parse_args();root=pathlib.Path(args.input);out=pathlib.Path(args.out);out.mkdir(parents=True,exist_ok=True)
groups={};diags=[]
for f in root.rglob('*.record.json'):
 r=json.loads(f.read_text())
 if r['local'] or r.get('smoke') or r['repeat']<0:continue
 if not (f.parent/'COMPLETE.json').exists():continue
 if r['result']['iterations']!=1000:continue
 if r['config']['diagnostic']:diags.append(r);continue
 groups.setdefault(r['config']['id'],[]).append(r)
rows=[];warnings=[]
for key,recs in groups.items():
 if len(recs)!=3 or {r['repeat'] for r in recs}!={0,1,2}:warnings.append(key+': incomplete/duplicate repeats');continue
 c=recs[0]['config'];vals=[r['result']['compute_seconds'] for r in recs];residuals=[r['result']['relative_residual'] for r in recs]
 if max(residuals)-min(residuals)>1e-10*max(1,max(residuals)):raise RuntimeError(key+': residual mismatch')
 rows.append(dict(id=key,suite=c['suite'],nx=c['n'][0],ny=c['n'][1],nz=c['n'][2],P=c['p'],T=c['t'],cores=c['cores'],nodes=recs[0]['result']['nodes'],grid='x'.join(map(str,c['grid'])),K=1000,median=statistics.median(vals),minimum=min(vals),maximum=max(vals),relative_residual=statistics.median(residuals)))
lookup={(r['suite'],r['nx'],r['P']):r for r in rows}
for r in rows:
 r.update(speedup='',efficiency='',baseline='')
 if r['suite']=='strong':
  basep=72 if r['nx']==512 else 1;b=lookup.get(('strong',r['nx'],basep))
  if b:r.update(speedup=b['median']/r['median'],efficiency=b['median']/r['median']/(r['P']/basep),baseline=f'MPI P={basep}')
 elif r['suite']=='weak':
  b=next((x for x in rows if x['suite']=='weak' and x['P']==1),None)
  if b:r.update(efficiency=b['median']/r['median'],baseline='weak P=1')
 else:
  b=lookup.get(('strong',256,r['cores']))
  if b:r.update(speedup=b['median']/r['median'],baseline=f'pure MPI P={r["cores"]}; layout improvement')
if rows:
 with (out/'summary.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
try:
 import matplotlib;matplotlib.use('Agg')
 import matplotlib.pyplot as plt
except ImportError:plt=None;warnings.append('matplotlib unavailable; CSV still generated')
if plt and rows:
 def save(fig,name):fig.tight_layout();fig.savefig(out/(name+'.png'),dpi=180);fig.savefig(out/(name+'.pdf'));plt.close(fig)
 strong=[r for r in rows if r['suite']=='strong']
 if strong:
  fig,axes=plt.subplots(1,3,figsize=(13,4))
  for n in sorted({r['nx'] for r in strong}):
   rs=sorted([r for r in strong if r['nx']==n],key=lambda x:x['P']);xs=[r['P'] for r in rs];ys=[r['median'] for r in rs];axes[0].errorbar(xs,ys,yerr=[[r['median']-r['minimum'] for r in rs],[r['maximum']-r['median'] for r in rs]],marker='o',label=f'{n}³')
   rs=[r for r in rs if r['speedup']!=''];axes[1].plot([r['P'] for r in rs],[r['speedup'] for r in rs],'o-',label=f'{n}³; base '+('72' if n==512 else '1'));axes[2].plot([r['P'] for r in rs],[100*r['efficiency'] for r in rs],'o-',label=f'{n}³')
  for ax,y in zip(axes,['Iteration time (s)','Speedup','Efficiency (%)']):ax.set_xscale('log',base=2);ax.set_xlabel('MPI ranks / CPU cores');ax.set_ylabel(y);ax.grid(True,alpha=.3);ax.legend(fontsize=7)
  axes[0].set_yscale('log');axes[1].set_yscale('log');save(fig,'strong_scaling')
 weak=sorted([r for r in rows if r['suite']=='weak'],key=lambda x:x['P'])
 if weak:
  fig,axes=plt.subplots(1,2,figsize=(9,4));axes[0].errorbar([r['P'] for r in weak],[r['median']/1000 for r in weak],yerr=[[ (r['median']-r['minimum'])/1000 for r in weak],[(r['maximum']-r['median'])/1000 for r in weak]],marker='o');axes[0].set_yscale('log');axes[0].set_ylabel('Seconds / iteration')
  valid=[r for r in weak if r['efficiency']!=''];axes[1].plot([r['P'] for r in valid],[100*r['efficiency'] for r in valid],'o-');axes[1].set_ylabel('Weak efficiency (%)')
  for ax in axes:ax.set_xscale('log',base=2);ax.set_xlabel('MPI ranks / CPU cores');ax.grid(True,alpha=.3)
  save(fig,'weak_scaling')
 hybrid=[r for r in rows if r['suite']=='hybrid']+[r for r in rows if r['suite']=='strong' and r['nx']==256 and r['P'] in (72,144)]
 if hybrid:
  hybrid.sort(key=lambda r:(r['cores'],-r['P']));fig,ax=plt.subplots(figsize=(9,4));ax.errorbar(range(len(hybrid)),[r['median'] for r in hybrid],yerr=[[r['median']-r['minimum'] for r in hybrid],[r['maximum']-r['median'] for r in hybrid]],fmt='o');ax.set_xticks(range(len(hybrid)),[f"{r['P']}×{r['T']}" for r in hybrid]);ax.set_yscale('log');ax.set_ylabel('Iteration time (s)');ax.set_xlabel('MPI ranks × OpenMP threads');save(fig,'hybrid_layouts')
diagrows=[]
for r in diags:
 times=r['result']['rank_timings'];slow=max(range(len(times)),key=lambda i:times[i][0]);t=times[slow]
 diagrows.append(dict(P=r['config']['p'],slowest_rank=slow,total=t[0],update=t[1],pack_unpack=t[2],communication_wait=t[3],swap=t[4],uninstrumented=t[0]-sum(t[1:]),min_rank_total=min(x[0] for x in times),max_rank_total=max(x[0] for x in times)))
if diagrows:
 with (out/'diagnostics.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(diagrows[0]));w.writeheader();w.writerows(diagrows)
(out/'audit.json').write_text(json.dumps(dict(formal_configurations=len(rows),diagnostics=len(diagrows),warnings=warnings),indent=2))
print(json.dumps(dict(formal_configurations=len(rows),diagnostics=len(diagrows),warnings=warnings)))
