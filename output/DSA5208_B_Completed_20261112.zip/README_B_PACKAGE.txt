B completed core follow-up, 12 November 2026

This B-only package includes all 39 required follow-up configurations,
the optional 2D and recovered 432/720 results, sources, report, derived tables,
raw evidence and checksums. Original-node probes remain queued optional
supplements; refer to the dated PBS snapshot rather than claiming completion.

Unzip this package into a new folder. Then extract
b_mpi/nov12/final_results_20261112/raw_evidence.zip at that folder's root.
Install matplotlib/reportlab and follow b_mpi/nov12/README.md to audit/rebuild.
The historical summary is included as the frozen Nov7 reference. Source and
binary hashes describe the original builds; no compiled programs or passwords
are distributed. Regenerate job templates with your own project name for new
Vanda submissions. Existing job IDs belong to the original account.
