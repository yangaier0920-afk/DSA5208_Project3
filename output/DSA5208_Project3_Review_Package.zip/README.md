# DSA5208 Project 3 - technical review package

Author names, student IDs and personal contribution statements are intentionally
omitted at the user's request. Add and personally review them before Canvas upload.
This package is a review edition, not a submission receipt.

Start with output/pdf/DSA5208_Project3_Review_Report.pdf. Editable Markdown is in
docs/final_report_review.md; B/C English chapters and a B code-review guide are included.

## Reported datasets

- A: ten serial configurations, three formal samples each; independent 3D numerical
  convergence/accuracy on 15/31/63. K=1000 scaling is separate from convergence.
- B: twenty scaling configurations plus eight paired-layout configurations, three
  formal samples each (84 total), and three separate diagnostics. Main summary.csv
  has 26 IDs/78 samples; six additional paired-control samples are represented in
  hybrid_summary.csv. Scaling uses matched CPU/topology and nominal 512-GB hosts.
  Actual scaling nodes at P72/144/288 are 3/4/9. The single-node 72-core hybrid
  comparison is a separate larger-memory paired cohort. Never substitute a scaling
  point for its paired pure-MPI control. Original slow P144 observations are retained.
- C: three grids x CPU1/CPU12/A40, with one warmup and three formal samples each.
  Resident and device-data-region end-to-end scopes are distinct; every GPU call
  has real offload evidence. Independent historical PBS exit status is unavailable.
- Optional 432/720-core queue requests have no accepted result and are omitted.

## Build (GNU / Open MPI compute node)

Load the site GCC/Open MPI stack; on Vanda source b_mpi/runtime_modules.sh.
Run make numerics scaling b-mpi c-cpu. For NVHPC GPU: make c-gpu, or
bash c_openmp/build.sh nvidia under NVHPC 24.7 / CUDA 12.3 / GCC 13.2.
The CPU/GPU build is intentionally split into C++ host and C target units.

A examples:
  build/jacobi_numerics --problem poisson3d_mms --nx 7 --max-iters 1000
  build/jacobi_a_scaling --problem poisson2d_mms --nx 7 --max-iters 1000
B validation (new output directory):
  python3 b_mpi/verify_b.py --binary build/jacobi_cart_hybrid --launcher 'mpirun --bind-to none' --out validation_b
C CPU checks:
  python3 c_openmp/run_c.py --binary c_openmp/build/jacobi_c_cpu --suite check --threads 2 --cpu-only --out validation_c

Mac: use OMPFLAGS='-Xpreprocessor -fopenmp -I/opt/homebrew/opt/libomp/include -L/opt/homebrew/opt/libomp/lib -lomp'
for the make targets. Homebrew Open MPI and libomp must already be available.
The Linux formal runner records OS CPU masks; --local mode is correctness-only.

## Formal reproduction

Use the supplied PBS generators and runners from a compute allocation. Replace
YOUR_PROJECT with your own valid CPU project. B launchers are restricted to
PBS_NODEFILE, bind ranks to their PEs and explicitly export OpenMP settings.
The run_b.py B_CASE_IDS filter selects a declared subset; for the standardized
72-rank scaling case use three 24-core chunks and select strong 128/256/512,
weak 384x256x192 and the 256-cube diagnostic, excluding hybrid thread layouts.
For the single-node 72-core paired hybrid study allocate 72 cores on one host
and retain its own MPI control. P144/P288 scaling use four 36-core / nine
32-core hosts in the same capacity class. Validate host model/memory and actual
CPU masks; do not oversubscribe or silently mix platform cohorts.
A's PBS and C's make_job.py specify their own allocation/module protocol.

## Reproduce the report figures without raw logs

Python >=3.10; install requirements-review.txt in a virtual environment.
From the package root:
  python3 closeout/plot_report.py
  python3 closeout/build_report.py

PDF building uses DejaVu fonts supplied with matplotlib; alternatively set
REPORT_FONT_DIR to the directory containing DejaVuSans.ttf and bold/oblique files.
All numerical inputs required by plot_report.py are included at their original
relative paths. Error bars show min/max, not confidence intervals.
The independent P144 review is separate from the original main series.

Raw stdout/stderr, scheduler output, terminal logs, binaries, full job archives,
credentials, SSH sockets and private connection configuration are excluded.
The public source manifest lists SHA256 for every included file. No email,
repository push or Canvas action is performed by this package.
